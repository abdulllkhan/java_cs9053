package pair;

public class Pair {
	
}
