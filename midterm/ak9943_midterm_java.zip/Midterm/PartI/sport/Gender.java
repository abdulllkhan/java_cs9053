package sport;

public enum Gender {
    
    MALE,
    FEMALE;

}
