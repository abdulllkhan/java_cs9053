
public class MyInitials {

	public static void main(String[] args) {

		System.out.println("  A     ZZZZZ   K   K");
		System.out.println(" A A        Z   K  K  ");
		System.out.println("A   A      Z    K K   ");
		System.out.println("AAAAA     Z     KK    ");
		System.out.println("A   A    Z      K K   ");
		System.out.println("A   A   Z       K  K  ");
		System.out.println("A   A   ZZZZZ   K   K ");

	}
}
