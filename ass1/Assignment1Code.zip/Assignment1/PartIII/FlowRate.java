public class FlowRate {

	public static double calculateFlowRate() {

		double pi = Math.PI;
		return -1;
	}
	
	public static void main(String[] args) {
		double radius = .0127;
		double length = 5;
		double eta = 8.9E-4;
		double pressureChange = 22000;
		double dyanmicViscosity = 8.9E-4;
		
		
		double flowRate = calculateFlowRate();
		System.out.println("The flow rate in liters/sec is: ");

	}
}